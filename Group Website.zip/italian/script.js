// cart object
let cart = {};
let total = 0;
// add item to cart
function addToCart(name, price, btn) {

    if (cart[name]) {
        cart[name].qty = cart[name].qty + 1;
    } else {
        cart[name] = {
            price: price,
            qty: 1
        };
    }
    updateCart();
    // button effect
    btn.classList.add("added");
    btn.innerText = "Added";
    setTimeout(function () {
        btn.classList.remove("added");
        btn.innerText = "Add to Cart";
    }, 800);
}
// update cart display
function updateCart() {
    let cartItems = document.getElementById("cartItems");
    cartItems.innerHTML = "";
    total = 0;
    let count = 0;
    for (let item in cart) {
        let itemTotal = cart[item].price * cart[item].qty;
        total = total + itemTotal;
        count = count + cart[item].qty;
        cartItems.innerHTML += `
            <div class="cart-item">
                <span class="cart-name">${item}</span>
                <div class="qty-control">
                    <button onclick="changeQty('${item}', -1)">-</button>
                    <span class="qty-number">${cart[item].qty}</span>
                    <button onclick="changeQty('${item}', 1)">+</button>
                </div>
                <span class="cart-price">₹${itemTotal}</span>
            </div>
        `;
    }
    document.getElementById("cartTotal").innerText = total;
    document.getElementById("cartCount").innerText = count;
}
// change quantity
function changeQty(item, value) {
    cart[item].qty = cart[item].qty + value;
    if (cart[item].qty <= 0) {
        delete cart[item];
    }
    updateCart();
}
// open or close cart
function toggleCart() {
    let cartBox = document.getElementById("cartBox");
    if (cartBox.style.display === "block") {
        cartBox.style.display = "none";
    } else {
        cartBox.style.display = "block";
    }
}
// filter food items
function filterFood(type) {
    let cards = document.querySelectorAll(".card");
    cards.forEach(function (card) {
        if (type === "all" || card.classList.contains(type)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}
// login modal
let isLogin = true;
function openAuth() {
    document.getElementById("authOverlay").style.display = "flex";
}
function closeAuth() {
    document.getElementById("authOverlay").style.display = "none";
}
function switchAuth() {
    isLogin = !isLogin;
    document.getElementById("authTitle").innerText =
        isLogin ? "Login" : "Sign Up";
    document.querySelector(".switch-text span").innerText =
        isLogin ? "Create account" : "Login instead";
}
// order section
function openOrder() {
    if (Object.keys(cart).length === 0) {
        alert("Cart is empty");
        return;
    }
    document.getElementById("orderOverlay").style.display = "flex";
}
function closeOrder() {
    document.getElementById("orderOverlay").style.display = "none";
}
function placeOrder() {
    let name = document.getElementById("custName").value;
    let phone = document.getElementById("custPhone").value;
    let address = document.getElementById("custAddress").value;
    let payment = document.querySelector('input[name="pay"]:checked').value;
    if (name === "" || phone === "" || address === "") {
        alert("Please fill all details");
        return;
    }
    alert(
        "Order placed successfully!\n\n" +
        "Customer Name: " + name +
        "\nMobile: " + phone +
        "\nPayment Method: " + payment +
        "\nTotal Amount: ₹" + total
    );
    cart = {};
    updateCart();
    closeOrder();
    toggleCart();
}
